#!/bin/bash

log() {
    echo "[*] $1"
}

validar_ipv4() {
    if [[ "$1" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
        for i in $(echo $1 | tr '.' ' '); do
            if ((i < 0 || i > 255)); then
                return 1
            fi
        done
        return 0
    fi
    return 1
}

validar_ipv6() {
    if [[ "$1" =~ ^([0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}$ ]]; then
        return 0
    fi
    return 1
}

validar_fqdn() {
    if [[ "$1" =~ ^([a-zA-Z0-9][-a-zA-Z0-9]*\.)+[a-zA-Z]{2,}$ ]]; then
        return 0
    fi
    return 1
}

iniciar_asistente() {
    clear
    echo "===== Asistente de configuración de zonas DNS autoritativas ====="

    read -rp "Ingrese el dominio principal (ej. ejemplo.com): " dominio
    while ! validar_fqdn "$dominio"; do
        echo "Dominio inválido. Inténtelo de nuevo."
        read -rp "Ingrese el dominio principal (ej. ejemplo.com): " dominio
    done
    nombre_sin_tld=$(echo "$dominio" | cut -d'.' -f1)

    read -rp "Ingrese las IPs públicas IPv4 para los registros PTR (separadas por espacio): " -a ipv4s
    for ip in "${ipv4s[@]}"; do
        if ! validar_ipv4 "$ip"; then
            echo "IPv4 inválida: $ip"
            exit 1
        fi
    done

    read -rp "Ingrese las IPs públicas IPv6 para los registros PTR (separadas por espacio): " -a ipv6s
    for ip in "${ipv6s[@]}"; do
        if ! validar_ipv6 "$ip"; then
            echo "IPv6 inválida: $ip"
            exit 1
        fi
    done

    read -rp "Ingrese los nombres de host para cada IP (en el mismo orden, separados por espacio): " -a ptr_nombres
    total_ips=$(( ${#ipv4s[@]} + ${#ipv6s[@]} ))
    if (( ${#ptr_nombres[@]} != total_ips )); then
        echo "Error: El número de nombres no coincide con el total de IPs proporcionadas."
        exit 1
    fi

    echo ""
    echo "Resumen:"
    echo " Dominio: $dominio"
    echo " IPv4: ${ipv4s[*]}"
    echo " IPv6: ${ipv6s[*]}"
    echo " Nombres PTR: ${ptr_nombres[*]}"
    echo ""

    echo "A continuación se generarán las zonas y configuraciones necesarias..."
    # Aquí continuarías con la lógica de generación real
    sleep 2
    echo "Zonas generadas correctamente."
}

iniciar_asistente
