# Asistente de configuración DNS

Este asistente guía al usuario paso a paso para generar archivos de zona DNS tipo directa o reversa, cumpliendo con las normativas de LACNIC.

## Archivos

- `asistente.sh`: Script principal de configuración.
- `README.md`: Este archivo.

## Uso

```bash
chmod +x asistente.sh
sudo ./asistente.sh
```
