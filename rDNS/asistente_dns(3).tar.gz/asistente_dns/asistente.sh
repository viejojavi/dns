#!/bin/bash
echo "Asistente de configuración DNS iniciado"

echo "Ingrese el nombre de la zona (ej. example.com):"
read zona

echo "Ingrese la dirección IP del servidor autorizado:"
read ip

echo "Ingrese el tipo de zona (directa o reversa):"
read tipo

if [[ "$tipo" == "directa" ]]; then
    archivo="/etc/bind/db.$zona"
    echo "\$TTL 86400
@ IN SOA ns1.$zona. admin.$zona. (
        2025041501 ; Serial
        3600       ; Refresh
        1800       ; Retry
        604800     ; Expire
        86400 )    ; Minimum TTL
@ IN NS ns1.$zona.
ns1 IN A $ip
www IN A $ip" > "$archivo"
    echo "Zona directa creada en $archivo"
else
    echo "Ingrese el prefijo IPv6 para la zona reversa (ej. 0.5.8.b.3.0.8.2):"
    read ipv6nibbles
    archivo="/etc/bind/db.$ipv6nibbles"
    echo "\$TTL 86400
@ IN SOA ns1.$zona. admin.$zona. (
        2025041501 ; Serial
        3600       ; Refresh
        1800       ; Retry
        604800     ; Expire
        86400 )    ; Minimum TTL
@ IN NS ns1.$zona.
1 IN PTR www.$zona." > "$archivo"
    echo "Zona reversa creada en $archivo"
fi
